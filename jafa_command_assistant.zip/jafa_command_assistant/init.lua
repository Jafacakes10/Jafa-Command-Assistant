if minetest.settings:get_bool("log_mods") then
	print("[JCA_Mod] Loaded!")
end

minetest.register_privilege("announce", {
    description = "This allows you to use the /shout command.",
    give_to_admin = true
})
dofile(minetest.get_modpath("jca") ..'/admin.lua')
dofile(minetest.get_modpath("jca") ..'/day.lua')
dofile(minetest.get_modpath("jca") ..'/fly.lua')
dofile(minetest.get_modpath("jca") ..'/info.lua')
dofile(minetest.get_modpath("jca") ..'/mute.lua')
dofile(minetest.get_modpath("jca") ..'/noadmin.lua')
dofile(minetest.get_modpath("jca") ..'/nofly.lua')
dofile(minetest.get_modpath("jca") ..'/shout.lua')
dofile(minetest.get_modpath("jca") ..'/stop.lua')
dofile(minetest.get_modpath("jca") ..'/tp.lua')
dofile(minetest.get_modpath("jca") ..'/unmute.lua')